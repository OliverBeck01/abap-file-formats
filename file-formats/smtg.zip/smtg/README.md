# SMTG File Format

File | Cardinality | Definition | Schema | Example
:--- | :--- | :--- | :--- | :---
`<name>.smtg.json` | 1 | [`zob_aff_smtg_v1.intf.abap`](./type/zob_aff_smtg_v1.intf.abap) | [`smtg-v1.json`](./smtg-v1.json)
